/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.html"],
  theme: {
    container: {
      center: true,
    },
    extend: {
      fontFamily: {
        vazir: ["vazir"],
      },
      colors: {
        "filimo-yellow": "#fdc13b",
        "filimo-green": "#1cb561",
      },
      backgroundImage: {
        "first-section-header-bg": "url('/src/images/payment_landing.png')",
        "first-article-img": "url('/src/images/1.jpg')",
        "second-section-img": "url('/src/images/2.jpg')",
        "cinema": "url('/src/images/bg-cinama.png')",
      },
    },
  },
  plugins: [],
};
