// let point = 12;

// switch (true) {
//   case point >= 15 && point <= 20:
//     console.log("A");
//     break;
//   case point >= 10 && point < 15:
//     console.log("B");
//     break;
//   case point >= 5 && point < 10:
//     console.log("C");
//     break;
//   case point >= 0 && point < 5:
//     console.log("D");
//     break;
//   default:
//     console.log("error");
// }

// console.log("hassan");
// console.log("hassan");
// console.log("hassan");
// console.log("hassan");
// console.log("hassan");

// $counter = 1;
// while ($counter <= 5) {
//   console.log("hassan");
//   $counter++;
// }

// $counter = 1;
// while ($counter <= 5000) {
//   console.log("hassan");
//   $counter++;
// }

// $counter = 1;
// while ($counter <= 100) {
//   console.log($counter);
//   $counter++;
// }

// $counter = 0;
// while ($counter <= 100) {
//   console.log($counter);
//   $counter += 10;
// }

// $counter = 100;
// while ($counter >= 0) {
//   console.log($counter);
//   $counter--;
// }

// $counter = 1;
// do {
//   console.log("hassan");
//   $counter++;
// } while ($counter <= 5);

// for (let i = 1; i <= 100; i++) {
//   console.log(i);
// }

for (let i = 1; i <= 3; i++) {
  console.log(`i => ${i}`);
  for (let j = 1; j <= 5; j++) {
    console.log(`j => ${j}`);
  }
}

// 8-1-1-1
